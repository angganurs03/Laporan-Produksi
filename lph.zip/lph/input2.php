<?php

include("ppic/koneksi.php");

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['save'])){

    // ambil data dari formulir
    $nomc = $_POST['nomc'];
    $nama = $_POST['nama'];
    $type = $_POST['type'];
    $noorder = $_POST['noorder'];
    $jumlah = $_POST['jumlah'];
    $tanggal = $_POST['tanggal'];
    $sisa= $_POST['sisa'];

    // buat query
    $sql = "INSERT INTO ppic (nomc, nama, type, noorder, jumlah,tanggal,sisa) VALUE ('$nomc', '$nama', '$type', '$noorder', '$jumlah','$tanggal','$sisa')";
    $query = mysqli_query($db, $sql);

    // apakah query simpan berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: index.php?status=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: index.php?status=gagal');
    }


} else {
    die("Akses dilarang...");
}

?>
