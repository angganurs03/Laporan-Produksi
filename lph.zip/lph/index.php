  <!DOCTYPE HTML>

<html>
  <script src="https://ajax.googleapis.com..."></script>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script type="text/javascript" src="common/js/form_init.js" id="form_init_script"
    data-name="">
    </script>
    <link rel="stylesheet" type="text/css" href="default.css"
    id="theme" />
    <title>
      lph ku
    </title>
  </head>

  <body><style>#docContainer .fb_cond_applied{ display:auto; }</style><noscript><style>#docContainer .fb_cond_applied{ display:inline-block; }</style></noscript>

        <form class="fb-toplabel fb-1000-item-column selected-object" id="docContainer"
action="" enctype="multipart/form-data" method="POST" novalidate="novalidate"
data-form="preview">
  <div class="fb-form-header" id="fb-form-header1">
    <a class="fb-link-logo" id="fb-link-logo1" style="max-width: 104px;" target="_blank"><img title="Alternative text" class="fb-logo" id="fb-logo1" style="width: 100%; display: none;" alt="Alternative text" src="common/images/image_default.png"/></a>
  </div>
  <div class="section" id="section1">
    <div class="column ui-sortable" id="column1">
      <div class="fb-item fb-100-item-column" id="item1">
        <div class="fb-header fb-item-alignment-center">
          <h2 style="display: inline;">
            Data Dari PPIC
          </h2>
        </div>
      </div>
      <div class="fb-item" id="item6" style="opacity: 1;">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
     <div class="fb-item fb-20-item-column" id="item4" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item4_label_0" style="display: inline;">Cari MC</label>
        </div>
        <div class="fb-dropdown">
          <select name="nomc" id="nomc" onkeyup="isi_otomatis()" required data-hint="">
            <option id="item4_0_option" selected value="">
              Cari Mesin
            </option>
            <option id="item4_1_option" value="1">
              1
            </option>
            <option id="item4_2_option" value="2">
              2
            </option>
            <option id="item4_3_option" value="3">
              3
            </option>
            <option id="item4_4_option" value="4">
              4
            </option>
            <option id="item4_5_option" value="5">
              5
            </option>
          </select>
        </div>
      </div>
      <div class="fb-item-alignment-left fb-footer" id="fb-submit-button-div"
  style="min-height: 1px;">
    <input class="" id="" style="border-width: 0px; font-family: times new roman; background-image: url('img/btn_submit.png');"
    type="submit" data-regular="url('img/btn_submit.png')"
    name="cari" value="CARI" />
  </div>
</form>
    <?php
if(ISSET($_POST['cari'])){
 require 'config.php';
 $nomc = $_POST['nomc'];
 $query = mysqli_query($conn, "SELECT * FROM `ppic` WHERE nomc = '$nomc' ORDER BY `nomc` ASC") or die(mysqli_error());
 while($fetch = mysqli_fetch_array($query)){
  ?>


<form class="fb-toplabel fb-100-item-column selected-object" id="myform" onSubmit="return validasi()" action="save.php" enctype="multipart/form-data" method="POST" novalidate="novalidate" data-form="preview">
      <div class="fb-item fb-20-item-column" id="item8">
        <div class="fb-grouplabel">
          <label id="item8_label_0" style="display: inline;">Nama </label>
        </div>

        <div class="fb-input-box">
         <input name="name" type="text" id="nama"  value="<?php echo $fetch['nama']?>" readonly="readonly" size="3" />

        </div>
      </div>

      <div class="fb-item fb-20-item-column" id="item9">
        <div class="fb-grouplabel">
          <label id="item9_label_0" style="display: inline;">Type</label>
        </div>
        <div class="fb-input-box">
          <input name="type" id="type" value="<?php echo $fetch['type']?>" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item13">
        <div class="fb-grouplabel">
          <label id="item13_label_0" style="display: inline;">No Oder</label>
        </div>
        <div class="fb-input-number">
          <input name="noorder" id="noorder" value="<?php echo $fetch['noorder']?>" type="number" min="0" max="7"
          step="1" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item15">
        <div class="fb-grouplabel">
          <label id="item15_label_0" style="display: inline;">Jumlah Order</label>
        </div>
        <div class="fb-input-number">
        	<input name="jumlah1" type="text"  id="jumlah"  onchange="hitung();"  value="<?php echo $fetch['jumlah']?>"></input>
        </div>
      </div>
      <?php
 }
}
?>

  <div class="fb-form-header" id="fb-form-header1">
    <a class="fb-link-logo" id="fb-link-logo1" style="max-width: 104px;" target="_blank"><img title="Alternative text" class="fb-logo" id="fb-logo1" style="width: 100%; display: none;" alt="Alternative text" src="common/images/image_default.png"/></a>
  </div>
  <div class="section" id="section1">
    <div class="column ui-sortable" id="column1">
      <div class="fb-item fb-100-item-column" id="item1">
        <div class="fb-header fb-item-alignment-center">
          <h2 style="display: inline;">
            Lembar Produksi Harian
          </h2>
        </div>
      </div>
      <div class="fb-item" id="item6" style="opacity: 1;">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>

      <div class="fb-item fb-25-item-column" id="item4" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item4_label_0" style="display: inline;">Nomor MC</label>
        </div>
        <div class="fb-dropdown">
          <select name="nomesin" id="pilihmc" required data-hint="">
            <option id="item4_0_option" selected value="">
              Pilih Mesin
            </option>
            <option id="item4_1_option" value="1">
              1
            </option>
            <option id="item4_2_option" value="2">
              2
            </option>
            <option id="item4_3_option" value="3">
              3
            </option>
            <option id="item4_4_option" value="4">
              4
            </option>
            <option id="item4_5_option" value="5">
              5
            </option>
          </select>
        </div>
      </div>

      <div class="fb-item fb-66-item-column fb-three-column" id="item5" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item5_label_0" style="display: inline;">Status MC</label>
        </div>
        <div class="fb-radio">
          <label id="item5_0_label"><input name="status" id="status" required type="radio" data-hint="" value="Produksi" /><span class="fb-fieldlabel" id="item5_0_span">Produksi</span></label>
          <label id="item5_1_label"><input name="status" id="item5_1_radio" required type="radio" value="Trobel MC" /><span class="fb-fieldlabel" id="item5_1_span">Trobel MC</span></label>
          <label id="item5_2_label"><input name="status" id="item5_2_radio" required type="radio" value="Trobel Produk" /><span class="fb-fieldlabel" id="item5_2_span">Trobel Produk</span></label>
          <label id="item5_3_label"><input name="status" id="item5_3_radio" required type="radio" value="Istirahat" /><span class="fb-fieldlabel" id="item5_3_span">Istirahat</span></label>
          <label id="item5_4_label"><input name="status" id="item5_4_radio" required type="radio" value="Balancing Stok" /><span class="fb-fieldlabel" id="item5_4_span">Balancing Stok</span></label>
          <label id="item5_5_label"><input name="status" id="item5_5_radio" required type="radio" value="No Assy" /><span class="fb-fieldlabel" id="item5_5_span">No Assy</span></label>
        </div>
      </div>
      <div class="fb-item" id="item3">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item11">
        <div class="fb-grouplabel">
          <label id="item11_label_0" style="display: inline;">Tanggal</label>
        </div>
        <div class="fb-input-box">
         <input name="tanggal" id="tanggal" type="date" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>




      <div class="fb-item" id="item14">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item17">
        <div class="fb-grouplabel">
          <label id="item17_label_0" style="display: inline;">Jam</label>
        </div>
        <div class="fb-input-box">
          <input name="text17" disabled id="item17_text_1" type="text" maxlength="254"
          placeholder="07.00-08.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item68">
        <div class="fb-html">
          <div id="item68_div_0">
            <label id="item17_label_0" style="display: inline;">Jumlah</label>
<div class="fb-input-box">
	<input name="jam1" type="text" id="txt1" onkeyup="sum();"  required="required"></input>
</div>
          </div>
        </div>
      </div>
            <script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript">
            $(document).ready(function() {
                $('#xt7').keyup(function(){
                <!-- Ambil nilai  !-->
                var xt1=parseInt($('#xt1').val());
                var xt2=parseInt($('#xt2').val());
                 var xt3=parseInt($('#xt3').val());
                  var xt4=parseInt($('#xt4').val());
                 var xt5=parseInt($('#xt5').val());
                  var xt6=parseInt($('#xt6').val());
                   var xt7=parseInt($('#xt7').val());
                <!-- Perhitungan !-->
                var total=xt1+xt2+xt3+xt4+xt5+xt6+xt7;
                $('#xt8').val(total);
                });
            });
            </script>

      <div class="fb-item fb-20-item-column" id="item22">
        <div class="fb-grouplabel">
          <label id="item22_label_0" style="display: inline;">Jumlah NG</label>
        </div>
        <div class="fb-input-box">
	<input class="xt1" type="text" name="ng1" id="xt1"  ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item19" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item19_label_0" style="display: inline;">KET.NG</label>
        </div>
        <div class="fb-input-box">
          <input name="ketng1" id="item19_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item20" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item20_label_0" style="display: inline;">KETERANGAN</label>
        </div>
        <div class="fb-input-box">
          <input name="ket1" id="item20_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item23">
        <div class="fb-grouplabel">
          <label id="item23_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text23" disabled id="item23_text_1" type="text" maxlength="254"
          placeholder="08.00-09.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item69">
        <div class="fb-html">
          <div id="item69_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam2" type="text" id="txt2" onkeyup="sum();"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item25">
        <div class="fb-grouplabel">
          <label id="item25_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
	<input class="xt2" type="text" name="ng2" id="xt2" ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item26" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item26_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng2" id="item26_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item27" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item27_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket2" id="item27_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item28">
        <div class="fb-grouplabel">
          <label id="item28_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text28" disabled id="item28_text_1" type="text" maxlength="254"
          placeholder="09.00-10.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item70">
        <div class="fb-html">
          <div id="item70_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam3" type="text" id="txt3" onkeyup="sum();"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item30">
        <div class="fb-grouplabel">
          <label id="item30_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
	<input class="xt3" type="text" name="ng3" id="xt3" ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item31" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item31_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng3" id="item31_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item32" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item32_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket3" id="item32_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item33">
        <div class="fb-grouplabel">
          <label id="item33_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text33" disabled id="item33_text_1" type="text" maxlength="254"
          placeholder="10.00-11.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item71">
        <div class="fb-html">
          <div id="item71_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam4" type="text" id="txt4" onkeyup="sum();"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item35">
        <div class="fb-grouplabel">
          <label id="item35_label_0" style="display: none;"></label>
        </div>
       <div class="fb-input-box">
	<input class="xt4" name="ng4" type="text" id="xt4" ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item36" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item36_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng4" id="item36_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item37" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item37_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket4" id="item37_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item38">
        <div class="fb-grouplabel">
          <label id="item38_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text38" disabled id="item38_text_1" type="text" maxlength="254"
          placeholder="11.00-12.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item72">
        <div class="fb-html">
          <div id="item72_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam5" type="text" id="txt5" onkeyup="sum();"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item40">
        <div class="fb-grouplabel">
          <label id="item40_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
	<input class="xt5" type="text" name="ng5" id="xt5" onchange="hitung();"></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item41" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item41_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng5" id="item41_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item42" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item42_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket5" id="item42_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item43">
        <div class="fb-grouplabel">
          <label id="item43_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text43" disabled id="item43_text_1" type="text" maxlength="254"
          placeholder="13.00-14.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item73">
        <div class="fb-html">
          <div id="item73_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam6" type="text" id="txt6" onkeyup="sum();"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item45">
        <div class="fb-grouplabel">
          <label id="item45_label_0" style="display: none;"></label>
        </div>
       <div class="fb-input-box">
	<input class="xt6" type="text" name="ng6" id="xt6"  onchange="hitung();"></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item46" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item46_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng6" id="item46_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item47" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item47_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket6" id="item47_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item48">
        <div class="fb-grouplabel">
          <label id="item48_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text48" disabled id="item48_text_1" type="text" maxlength="254"
          placeholder="14.00-15.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item74">
        <div class="fb-html">
          <div id="item74_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam7" type="text" id="txt7" onkeyup="sum();"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item50">
        <div class="fb-grouplabel">
          <label id="item50_label_0" style="display: none;"></label>
        </div>
      <div class="fb-input-box">
	<input class="xt7" type="text" name="ng7" id="xt7"  onchange="hitung();"></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item51" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item51_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng7" id="item51_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item52" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item52_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket7" id="item52_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item" id="item53">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item76">
        <div class="fb-html">
          <div id="item76_div_0">
            <label id="item17_label_0" style="display: inline;">Jumlah Produk</label>
<div class="fb-input-box">
	<input class="txt8" type="text" name="total" disable id="txt8" onchange="hitung();" ></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item56" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item56_label_0" style="display: inline;">Jumlah NG</label>
        </div>
        <div class="fb-input-box">
          <input class="xt8"  name="totalng"  type="text" id="xt8" ></input>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item57" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item57_label_0" style="display: inline;">Total Jam</label>
        </div>
        <div class="fb-input-box">
          <input name="totaljam" id="item57_text_1" type="text" maxlength="254"
          placeholder="" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item61">
        <div class="fb-grouplabel">
          <label id="item61_label_0" style="display: inline;">Nama Operator</label>
        </div>
        <div class="fb-input-box">
          <input name="nama" id="item61_text_1" type="text" maxlength="254"
          placeholder="" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item62">
        <div class="fb-grouplabel">
          <label id="item62_label_0" style="display: inline;">NIK</label>
        </div>
        <div class="fb-input-box">
          <input name="nik" id="item62_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item77">
        <div class="fb-html">
          <div id="item77_div_0">
            <label id="item17_label_0" style="display: inline;">Jumlah Order</label>
<div class="fb-input-box">
	<input class=txt10 type="text" placeholder="Tulis ULang Jumlah Order" id="txt10" name="txt10" onchange="hitung();"></input>
</div>
          </div>
        </div>
      </div>
          <script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript">
            $(document).ready(function() {
                $('#txt10').keyup(function(){
                <!-- Ambil nilai  !-->
                var satu=parseInt($('#txt10').val());
                var dua=parseInt($('#txt8').val());
             var hasil=satu-dua;
                $('#txt11').val(hasil);
                });
            });
            </script>
      <div class="fb-item fb-20-item-column" id="item80">
        <div class="fb-html">
          <div id="item80_div_0">
            <label id="item17_label_0" style="display: inline;">Sisa Order</label>
<div class="fb-input-box">

	<input class="txt11" type="text" name="sisa" id="txt11" ></input>

</div>
          </div>
        </div>
      </div>
      </div>
      <div id="show-product">
        <!-- data akan di tampilkan di sini -->
      </div>
      <div class="fb-item fb-100-item-column" id="item82" style="opacity: 1;">
        <div class="fb-html">
          <div id="item82_div_0">

          </div>
        </div>
      </div>
      <div class="fb-item fb-100-item-column" id="item75" style="opacity: 1;">
        <div class="fb-html">     <div id="item75_div_0">
         <script>function sum() {
      var txtFirstNumberValue = document.getElementById('txt1').value;
      var txtSecondNumberValue = document.getElementById('txt2').value;
      var txtTigaNumberValue = document.getElementById('txt3').value;
      var txtEmpatNumberValue = document.getElementById('txt4').value;
         var txtLimaNumberValue = document.getElementById('txt5').value;
       var txtEnamNumberValue = document.getElementById('txt6').value;
     var txtTujuhNumberValue = document.getElementById('txt7').value;

      var result = parseInt(txtFirstNumberValue) + parseInt(txtSecondNumberValue)+parseInt(txtTigaNumberValue)+parseInt(txtEmpatNumberValue)+parseInt(txtLimaNumberValue)+parseInt(txtEnamNumberValue)+parseInt(txtTujuhNumberValue);
      if (!isNaN(result)) {
         document.getElementById('txt8').value = result;

      }
}</script>

          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="fb-captcha fb-item-alignment-center" id="fb-captcha_control"
  style="display: none; cursor: default;">
    <img src="editordata/images/recaptcharecaptchav2-light.png" />
  </div>
  <div class="fb-item-alignment-left fb-footer" id="fb-submit-button-div"
  style="min-height: 1px;">
    <input class="fb-button-special non-standard" name="save" id="fb-submit-button" style="border-width: 0px; font-family: times new roman; background-image: url('img/btn_submit.png');"
    type="submit" data-regular="url('imag/btn_submit.png')"
    value="SAVE" />
  </div>
   <script src="js/jquery-3.2.1.min.js"></script>
 <script src="js/bootstrap.js"></script>
</form>
        <?php if(isset($_GET['status'])): ?>
    <p>
        <?php
            if($_GET['status'] == 'sukses'){
                echo "Laporan Berhasil Disimpan";
            } else {
                echo "Laporan gagal disimpan";
            }
        ?>
    </p>
<?php endif; ?>


<script type="text/javascript">


function validasi()

    {


        var pilihmc=document.forms["myform"]["pilihmc"].value;
         var status=document.forms["myform"]["status"].value;

//        validasi nip tidak boleh kosong (required)

        if (pilihmc==null || pilihmc=="")

          {

          alert("Mesin Wajib di pilih!");

          return false;

          };
 if (status==null || status=="")

          {

          alert("Status Mesin Wajib di pilih!");

          return false;

          };

}
</script>
</body>
</html>
