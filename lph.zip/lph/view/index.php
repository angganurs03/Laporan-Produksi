  <!DOCTYPE HTML>

<html>
  <script src="https://ajax.googleapis.com..."></script>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script type="text/javascript" src="common/js/form_init.js" id="form_init_script"
    data-name="">
    </script>
    <link rel="stylesheet" type="text/css" href="default.css"
    id="theme" />
    <title>
      Monitoring LPH
    </title>
  </head>

  <body><style>#docContainer .fb_cond_applied{ display:auto; }</style><noscript><style>#docContainer .fb_cond_applied{ display:inline-block; }</style></noscript>

        <form class="fb-toplabel fb-1000-item-column selected-object" id="docContainer"
action="" enctype="multipart/form-data" method="POST" novalidate="novalidate"
data-form="preview">
  <div class="fb-form-header" id="fb-form-header1">
    <a class="fb-link-logo" id="fb-link-logo1" style="max-width: 104px;" target="_blank"><img title="Alternative text" class="fb-logo" id="fb-logo1" style="width: 100%; display: none;" alt="Alternative text" src="common/images/image_default.png"/></a>
  </div>
  <div class="section" id="section1">
    <div class="column ui-sortable" id="column1">
      <div class="fb-item fb-100-item-column" id="item1">
       </div>
      </div>
      </div>
    <?php
if(ISSET($_POST['cari'])){
 require 'config.php';
$nomesin=$_POST['nomesin'];
$tanggal=$_POST ['tanggal'];
 $query=mysqli_query($conn, "SELECT * FROM lph WHERE nomesin='$nomesin' AND tanggal='$tanggal' ")or die();
while($fetch = mysqli_fetch_array($query))
{
  ?>
<form class="fb-toplabel fb-100-item-column selected-object" id="myform" onSubmit="return validasi()" action="save.php" enctype="multipart/form-data" method="POST" novalidate="novalidate" data-form="preview">
  
   
  <div class="fb-form-header" id="fb-form-header1">
    <a class="fb-link-logo" id="fb-link-logo1" style="max-width: 104px;" target="_blank"><img title="Alternative text" class="fb-logo" id="fb-logo1" style="width: 100%; display: none;" alt="Alternative text" src="common/images/image_default.png"/></a>
  </div>
  <div class="section" id="section1">
    <div class="column ui-sortable" id="column1">
      <div class="fb-item fb-100-item-column" id="item1">
        <div class="fb-header fb-item-alignment-center">
          <h2 style="display: inline;">
            Lembar Produksi Harian
          </h2>
        </div>
      </div>
    
      <div class="fb-item" id="item3">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
 <div class="fb-item fb-20-item-column" id="item11">
        <div class="fb-grouplabel">
          <label id="item11_label_0" style="display: inline;">No Mesin</label>
        </div>
        <div class="fb-input-box">
         <input name="nomesin" disabled id="nomesin" type="text" value="<?php echo $fetch['nomesin']?>"   maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
 <div class="fb-item fb-20-item-column" id="item11">
        <div class="fb-grouplabel">
          <label id="item11_label_0" style="display: inline;">Status</label>
        </div>
        <div class="fb-input-box">
         <input name="status" disabled id="status" type="text" value="<?php echo $fetch['status']?>"   maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>

 <div class="fb-item fb-20-item-column" id="item11">
        <div class="fb-grouplabel">
          <label id="item11_label_0" style="display: inline;">Sisa Order</label>
        </div>
        <div class="fb-input-box">
         <input name="sisa" disabled id="sisa" type="text" value="<?php echo $fetch['sisa']?>"   maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>

<br>
      <div class="fb-item fb-20-item-column" id="item11">
        <div class="fb-grouplabel">
          <label id="item11_label_0" style="display: inline;">Tanggal</label>
        </div>
        <div class="fb-input-box">
         <input name="tanggal" disabled id="tanggal" type="date" value="<?php echo $fetch['tanggal']?>"   maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
<div class="fb-item fb-20-item-column" id="item8">
        <div class="fb-grouplabel">
          <label id="item8_label_0" style="display: inline;">Nama </label>
        </div>

        <div class="fb-input-box">
         <input name="name" type="text" disabled id="nama"  value="<?php echo $fetch['name']?>" readonly="readonly" size="3" />

        </div>
      </div>

      <div class="fb-item fb-20-item-column" id="item9">
        <div class="fb-grouplabel">
          <label id="item9_label_0" style="display: inline;">Type</label>
        </div>
        <div class="fb-input-box">
          <input name="type" disabled id="type" value="<?php echo $fetch['type']?>" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item13">
        <div class="fb-grouplabel">
          <label id="item13_label_0" style="display: inline;">No Oder</label>
        </div>
        <div class="fb-input-number">
          <input name="noorder" disabled id="noorder" value="<?php echo $fetch['noorder']?>" type="number" min="0" max="7"
          step="1" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item15">
        <div class="fb-grouplabel">
          <label id="item15_label_0" style="display: inline;">Jumlah Order</label>
        </div>
        <div class="fb-input-number">
        	<input name="jumlah1" type="text" disabled id="jumlah"  onchange="hitung();"  value="<?php echo $fetch['jumlah1']?>"></input>
        </div>
      </div>


      <div class="fb-item" id="item14">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item17">
        <div class="fb-grouplabel">
          <label id="item17_label_0" style="display: inline;">Jam</label>
        </div>
        <div class="fb-input-box">
          <input name="text17" disabled id="item17_text_1" type="text" maxlength="254"
          placeholder="07.00-08.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item68">
        <div class="fb-html">
          <div id="item68_div_0">
            <label id="item17_label_0" style="display: inline;">Jumlah</label>
<div class="fb-input-box">
	<input name="jam1" type="text" disabled id="jam1" onkeyup="sum();"  required="required" value="<?php echo $fetch['jam1']?>"></input>
</div>
          </div>
        </div>
      </div>
   

      <div class="fb-item fb-20-item-column" id="item22">
        <div class="fb-grouplabel">
          <label id="item22_label_0" style="display: inline;">Jumlah NG</label>
        </div>
        <div class="fb-input-box">
	<input class="xt1" type="text" name="ng1" disabled id="xt1"   value="<?php echo $fetch['ng1']?>"></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item19" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item19_label_0" style="display: inline;">KET.NG</label>
        </div>
        <div class="fb-input-box">
          <input name="ketng1" disabled id="item19_text_1" type="text" value="<?php echo $fetch['ketng1']?>"  maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item20" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item20_label_0" style="display: inline;">KETERANGAN</label>
        </div>
        <div class="fb-input-box">
          <input name="ket1" disabled id="item20_text_1" type="text" value="<?php echo $fetch['ketng1']?>" 
maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item23">
        <div class="fb-grouplabel">
          <label id="item23_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text23" disabled id="item23_text_1" type="text" maxlength="254"
          placeholder="08.00-09.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item69">
        <div class="fb-html">
          <div id="item69_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam2" type="text" disabled id="txt2" onkeyup="sum();" value="<?php echo $fetch['jam2']?>" ></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item25">
        <div class="fb-grouplabel">
          <label id="item25_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
	<input class="xt2" type="text" name="ng2"disabled id="xt2"  value="<?php echo $fetch['ng2']?>"  ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item26" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item26_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng2" disabled id="item26_text_1" type="text" maxlength="254" placeholder="" value="<?php echo $fetch['ketng2']?>"
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item27" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item27_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket2" disabled id="item27_text_1" type="text" maxlength="254" placeholder="" value="<?php echo $fetch['ket2']?>"
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item28">
        <div class="fb-grouplabel">
          <label id="item28_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text28" disabled id="item28_text_1" type="text" maxlength="254"
          placeholder="09.00-10.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item70">
        <div class="fb-html">
          <div id="item70_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam3" type="text"  disabled id="txt3" onkeyup="sum();"   value="<?php echo $fetch['jam3']?>"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item30">
        <div class="fb-grouplabel">
          <label id="item30_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
	<input class="xt3" type="text" name="ng3" disabled id="xt3" value="<?php echo $fetch['ng3']?>" ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item31" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item31_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng3" disabled id="item31_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off"   value="<?php echo $fetch['ketng3']?>"  />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item32" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item32_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket3" disabled id="item32_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" value="<?php echo $fetch['ket3']?>"/>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item33">
        <div class="fb-grouplabel">
          <label id="item33_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text33" disabled id="item33_text_1" type="text" maxlength="254"
          placeholder="10.00-11.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item71">
        <div class="fb-html">
          <div id="item71_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam4" type="text" disabled id="txt4" onkeyup="sum();" value="<?php echo $fetch['jam4']?>"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item35">
        <div class="fb-grouplabel">
          <label id="item35_label_0" style="display: none;"></label>
        </div>
       <div class="fb-input-box">
	<input class="xt4" name="ng4" type="text" disabled id="xt4" value="<?php echo $fetch['ng4']?>" ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item36" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item36_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng4" disabled id="item36_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off"   value="<?php echo $fetch['ketng4']?>"/>
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item37" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item37_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket4" disabled id="item37_text_1" type="text" maxlength="254" placeholder="" value="<?php echo $fetch['ket4']?>"
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item38">
        <div class="fb-grouplabel">
          <label id="item38_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text38" disabled id="item38_text_1" type="text" maxlength="254"
          placeholder="11.00-12.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item72">
        <div class="fb-html">
          <div id="item72_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam5" type="text" disabled id="txt5" onkeyup="sum();" value="<?php echo $fetch['jam5']?>"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item40">
        <div class="fb-grouplabel">
          <label id="item40_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
	<input class="xt5" type="text" name="ng5" disabled id="xt5" onchange="hitung();" value="<?php echo $fetch['ng5']?>" ></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item41" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item41_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng5" disabled id="item41_text_1" type="text" maxlength="254" placeholder="" value="<?php echo $fetch['ketng5']?>"
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item42" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item42_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket5"  disabled id="item42_text_1" type="text" maxlength="254" placeholder="" value="<?php echo $fetch['ket5']?>"
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item43">
        <div class="fb-grouplabel">
          <label id="item43_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text43" disabled id="item43_text_1" type="text" maxlength="254"
          placeholder="13.00-14.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item73">
        <div class="fb-html">
          <div id="item73_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam6" type="text" disabled id="txt6" onkeyup="sum();"  value="<?php echo $fetch['jam6']?>" ></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item45">
        <div class="fb-grouplabel">
          <label id="item45_label_0" style="display: none;"></label>
        </div>
       <div class="fb-input-box">
	<input class="xt6" type="text" name="ng6" disabled id="xt6"  onchange="hitung();"  value="<?php echo $fetch['ng6']?>"></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item46" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item46_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng6" disabled id="item46_text_1" type="text" maxlength="254" placeholder=""  value="<?php echo $fetch['ketng6']?>"
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item47" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item47_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket6" disabled id="item47_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" value="<?php echo $fetch['ket6']?>"
/>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item48">
        <div class="fb-grouplabel">
          <label id="item48_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="text48" disabled id="item48_text_1" type="text" maxlength="254"
          placeholder="14.00-15.00" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item74">
        <div class="fb-html">
          <div id="item74_div_0">
            <label id="item17_label_0" style="display: inline;"></label>
<div class="fb-input-box">
	<input name="jam7" type="text" disabled id="txt7" onkeyup="sum();" value="<?php echo $fetch['jam7']?>"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item50">
        <div class="fb-grouplabel">
          <label id="item50_label_0" style="display: none;"></label>
        </div>
      <div class="fb-input-box">
	<input class="xt7" type="text" name="ng7" disabled id="xt7"  onchange="hitung();"  value="<?php echo $fetch['ng7']?>"></input>
</div>
</div>
      <div class="fb-item fb-25-item-column" id="item51" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item51_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ketng7" disabled id="item51_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" value="<?php echo $fetch['ketng7']?>" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item52" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item52_label_0" style="display: none;"></label>
        </div>
        <div class="fb-input-box">
          <input name="ket7" disabled id="item52_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off"  value="<?php echo $fetch['ket7']?>"/>
        </div>
      </div>
      <div class="fb-item" id="item53">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item76">
        <div class="fb-html">
          <div id="item76_div_0">
            <label id="item17_label_0" style="display: inline;">Jumlah Produk</label>
<div class="fb-input-box">
	<input class="txt8" type="text" name="total" disabled id="txt8" onchange="hitung();"   value="<?php echo $fetch['total']?>"></input>
</div>
          </div>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item56" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item56_label_0" style="display: inline;">Jumlah NG</label>
        </div>
        <div class="fb-input-box">
          <input class="xt8"  name="totalng"  type="text" disabled id="xt8"   value="<?php echo $fetch['totalng']?>"></input>
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item57" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item57_label_0" style="display: inline;">Total Jam</label>
        </div>
        <div class="fb-input-box">
          <input name="totaljam" disabled id="item57_text_1" type="text" maxlength="254"
          placeholder="" data-hint="" autocomplete="off"   value="<?php echo $fetch['totaljam']?>"/>
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item61">
        <div class="fb-grouplabel">
          <label id="item61_label_0" style="display: inline;">Nama Operator</label>
        </div>
        <div class="fb-input-box">
          <input name="nama" disabled id="item61_text_1" type="text" maxlength="254"
          placeholder="" data-hint="" autocomplete="off"  value="<?php echo $fetch['nama']?>"/>
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item62">
        <div class="fb-grouplabel">
          <label id="item62_label_0" style="display: inline;">NIK</label>
        </div>
        <div class="fb-input-box">
          <input name="nik" disabled id="item62_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off"   value="<?php echo $fetch['nik']?>"/>
        </div>
      </div>

      <?php
 }
    
 // menampilkan pesan zero data
 {echo 'Maaf, hasil pencarian tidak ditemukan.'; }
}
?>
      <div class="fb-item fb-20-item-column" id="item77">
        <div class="fb-html">
          <div id="item77_div_0">
</div>
          </div>
        </div>
      <div class="fb-item fb-20-item-column" id="item80">
        <div class="fb-html">
          <div id="item80_div_0">
        </div>
      </div>
      </div>
      <div id="show-product">
        <!-- data akan di tampilkan di sini -->
      </div>
      <div class="fb-item fb-100-item-column" id="item82" style="opacity: 1;">
        <div class="fb-html">
          <div id="item82_div_0">

          </div>
        </div>
      </div>
      <div class="fb-item fb-100-item-column" id="item75" style="opacity: 1;">
        <div class="fb-html">     <div id="item75_div_0">

          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="fb-captcha fb-item-alignment-center" id="fb-captcha_control"
  style="display: none; cursor: default;">
    <img src="editordata/images/recaptcharecaptchav2-light.png" />
  </div>
  <div class="fb-item-alignment-left fb-footer" id="fb-submit-button-div"
  style="min-height: 1px;">
    <input class="fb-button-special non-standard" name="save" id="fb-submit-button" onClick="window.print();"
style="border-width: 0px; font-family: times roman; background-image: url('img/btn_submit.png');"
    type="button" data-regular="url('imag/btn_submit.png')"
    value="PRINT" />
  </div>
   <script src="js/jquery-3.2.1.min.js"></script>
 <script src="js/bootstrap.js"></script>
</form>
       
</body>
</html>
