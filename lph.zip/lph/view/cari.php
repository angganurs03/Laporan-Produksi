 <!DOCTYPE HTML>

<html>
  <script src="https://ajax.googleapis.com..."></script>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script type="text/javascript" src="common/js/form_init.js" id="form_init_script"
    data-name="">
    </script>
    <link rel="stylesheet" type="text/css" href="default.css"
    id="theme" />
    <title>
      Monitoring LPH
    </title>
  </head>

  <body><style>#docContainer .fb_cond_applied{ display:auto; }</style><noscript><style>#docContainer .fb_cond_applied{ display:inline-block; }</style></noscript>

        <form class="fb-toplabel fb-1000-item-column selected-object" id="docContainer"
action="index.php" enctype="multipart/form-data" method="POST" novalidate="novalidate"
data-form="preview">
  <div class="fb-form-header" id="fb-form-header1">
    <a class="fb-link-logo" id="fb-link-logo1" style="max-width: 104px;" target="_blank"><img title="Alternative text" class="fb-logo" id="fb-logo1" style="width: 100%; display: none;" alt="Alternative text" src="common/images/image_default.png"/></a>
  </div>
  <div class="section" id="section1">
    <div class="column ui-sortable" id="column1">
      <div class="fb-item fb-100-item-column" id="item1">
        <div class="fb-header fb-item-alignment-center">
          <h2 style="display: inline;">
            Cari Data
          </h2>
        </div>
      </div>
      <div class="fb-item" id="item6" style="opacity: 1;">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
     <div class="fb-item fb-20-item-column" id="item4" style="opacity: 1;">
        <div class="fb-grouplabel">
          <label id="item4_label_0" style="display: inline;">Cari MC</label>
        </div>
        <div class="fb-dropdown">
          <select name="nomesin" id="nomesin" onkeyup="isi_otomatis()" required data-hint="">
            <option id="item4_0_option" selected value="">
              Cari Mesin
            </option>
            <option id="item4_1_option" value="1">
              1
            </option>
            <option id="item4_2_option" value="2">
              2
            </option>
            <option id="item4_3_option" value="3">
              3
            </option>
            <option id="item4_4_option" value="4">
              4
            </option>
            <option id="item4_5_option" value="5">
              5
            </option>
          </select>
      </div>
      </div>
<div class="fb-item fb-20-item-column" id="item11"> <div class="fb-grouplabel"> <label id="item11_label_0" style="display: inline;">Tanggal</label> </div> <div class="fb-input-box"> <input name="tanggal" id="tanggal" type="date" maxlength="254" placeholder="" data-hint="" autocomplete="off" /> </div> </div></div>

  <div class="fb-item-alignment-left fb-footer" id="fb-submit-button-div"
  style="min-height: 1px;">
    <input class="fb-button-special non-standard" name="cari" id="fb-submit-button" style="border-width: 0px; font-family: times new roman; background-image: url('img/btn_submit.png');"
    type="submit" data-regular="url('imag/btn_submit.png')"
    value="Cari" />
  </div>
</form>
</body>
</html>