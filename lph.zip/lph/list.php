            <?php include("koneksi.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>List </title>
</head>

<body>
    <header>
        <h3>LIST MESIN PRODUKSI</h3>
    </header>

    <nav>
        <a href="index.php">[+] Tambah Baru</a>
    </nav>


		</table>



    <br>

    <table border="5">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Part</th>
            <th>Type</th>
            <th>No Order</th>
            <th>Jumlah Order</th>
            <th>No Mesin</th>
            <th>Status</th>
            <th>Tanggal</th>
            <th>07.00-0800</th>
            <th>NG</th>
            <th>ket NG</th>
            <th>Ket STOP</th>
            <th>08.00-0900</th>
            <th>NG</th>
            <th>ket NG</th>
            <th>Ket STOP</th>
            <th>09.00-10.00</th>
            <th>NG</th>
            <th>ket NG</th>
            <th>Ket STOP</th>
            <th>10.00-11.00</th>
            <th>NG</th>
            <th>ket NG</th>
            <th>Ket STOP</th>
            <th>11.00-12.00</th>
            <th>NG</th>
            <th>ket NG</th>
            <th>Ket STOP</th>
            <th>13.00-14.00</th>
            <th>NG</th>
            <th>ket NG</th>
            <th>Ket STOP</th>
            <th>14.00-15.00</th>
            <th>NG</th>
            <th>ket NG</th>
            <th>Ket STOP</th>
            <th>JUMLAH PRODUK</th>
            <th>Sisa Orderan </th>
            <th>Jumlah NG</th>
            <th>Jumlah jam</th>
            <th>Nama</th>
            <th>NIK</th>
            <th>Tindakan</th>
        </tr>
    </thead>


    <tbody>


        <?php
        $sql = "SELECT * FROM lph";
        $query = mysqli_query($db, $sql);
        while($siswa = mysqli_fetch_array($query)){
            echo "<tr>";

            echo "<td>".$siswa['id']."</td>";
            echo "<td>".$siswa['name']."</td>";
           echo "<td>".$siswa['type']."</td>";
           echo "<td>".$siswa['noorder']."</td>";
              echo "<td>".$siswa['jumlah1']."</td>";
            echo "<td>".$siswa['nomesin']."</td>";
            echo "<td>".$siswa['status']."</td>";
            echo "<td>".$siswa['tanggal']."</td>";
            echo "<td>".$siswa['jam1']."</td>";
            echo "<td>".$siswa['ng1']."</td>";
            echo "<td>".$siswa['ketng1']."</td>";
             echo "<td>".$siswa['ket1']."</td>";
              echo "<td>".$siswa['jam2']."</td>";
            echo "<td>".$siswa['ng2']."</td>";
            echo "<td>".$siswa['ketng2']."</td>";
             echo "<td>".$siswa['ket2']."</td>";
              echo "<td>".$siswa['jam3']."</td>";
            echo "<td>".$siswa['ng3']."</td>";
            echo "<td>".$siswa['ketng3']."</td>";
             echo "<td>".$siswa['ket3']."</td>";
              echo "<td>".$siswa['jam4']."</td>";
            echo "<td>".$siswa['ng4']."</td>";
            echo "<td>".$siswa['ketng4']."</td>";
             echo "<td>".$siswa['ket4']."</td>";
              echo "<td>".$siswa['jam5']."</td>";
            echo "<td>".$siswa['ng5']."</td>";
            echo "<td>".$siswa['ketng5']."</td>";
             echo "<td>".$siswa['ket5']."</td>";
              echo "<td>".$siswa['jam6']."</td>";
            echo "<td>".$siswa['ng6']."</td>";
            echo "<td>".$siswa['ketng6']."</td>";
             echo "<td>".$siswa['ket6']."</td>";
              echo "<td>".$siswa['jam7']."</td>";
            echo "<td>".$siswa['ng7']."</td>";
            echo "<td>".$siswa['ketng7']."</td>";
             echo "<td>".$siswa['ket7']."</td>";
             echo "<td>".$siswa['total']."</td>";
            echo "<td>".$siswa['sisa']."</td>";
             echo "<td>".$siswa['totalng']."</td>";
            echo "<td>".$siswa['totaljam']."</td>";
             echo "<td>".$siswa['nama']."</td>";
             echo "<td>".$siswa['nik']."</td>";
                echo "<td>";
            echo "<a href='edit.php?id=".$siswa['id']."'>Edit</a> | ";
            echo "<a href='hapus.php?id=".$siswa['id']."'>Hapus</a>";
            echo "</td>";

            echo "</tr>";
        }
        ?>

    </tbody>
    </table>

    <p>Total: <?php echo mysqli_num_rows($query) ?></p>




    </body>
</html>

