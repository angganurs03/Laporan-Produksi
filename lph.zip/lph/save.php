<?php

include("koneksi.php");

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['save'])){

    // ambil data dari formulir
    $name = $_POST['name'];
    $type= $_POST['type'];
    $noorder = $_POST['noorder'];
    $jumlah1 = $_POST['jumlah1'];
    $nomesin = $_POST['nomesin'];
    $status = $_POST['status'];
    $tanggal= $_POST['tanggal'];
    $jam1 = $_POST['jam1'];
    $jam2 = $_POST['jam2'];
    $jam3 = $_POST['jam3'];
    $jam4 = $_POST['jam4'];
    $jam5 = $_POST['jam5'];
    $jam6 = $_POST['jam6'];
    $jam7 = $_POST['jam7'];
    $ng1 = $_POST['ng1'];
    $ng2 = $_POST['ng2'];
    $ng3 = $_POST['ng3'];
    $ng4 = $_POST['ng4'];
    $ng5 = $_POST['ng5'];
    $ng6 = $_POST['ng6'];
    $ng7 = $_POST['ng7'];
    $ketng1 = $_POST['ketng1'];
    $ketng2 = $_POST['ketng2'];
    $ketng3 = $_POST['ketng3'];
    $ketng4 = $_POST['ketng4'];
    $ketng5 = $_POST['ketng5'];
    $ketng6 = $_POST['ketng6'];
    $ketng7 = $_POST['ketng7'];
    $ket1 = $_POST['ket1'];
    $ket2 = $_POST['ket2'];
    $ket3 = $_POST['ket3'];
    $ket4 = $_POST['ket4'];
    $ket5 = $_POST['ket5'];
    $ket6 = $_POST['ket6'];
    $ket7 = $_POST['ket7'];
    $total = $_POST['total'];
    $totalng = $_POST['totalng'];
    $totaljam = $_POST['totaljam'];
    $nama = $_POST['nama'];
     $nik = $_POST['nik'];
      $sisa= $_POST ['sisa'];
      
    // buat query
    $sql = "INSERT INTO lph (name,type,noorder,jumlah1,nomesin , status , tanggal,jam1,jam2,jam3,jam4,jam5,jam6,jam7,ng1,ng2,ng3,ng4,ng5,ng6,ng7,ketng1,ketng2,ketng3,ketng4,ketng5,ketng6,ketng7,ket1,ket2,ket3,ket4,ket5,ket6,ket7,total,totalng,totaljam,nama,nik,sisa
) VALUE ('$name','$type','$noorder','$jumlah1','$nomesin','$status','$tanggal','$jam1','$jam2','$jam3','$jam4','$jam5','$jam6','$jam7','$ng1','$ng2','$ng3','$ng4','$ng5','$ng6','$ng7','$ketng1','$ketng2','$ketng3','$ketng4','$ketng5','$ketng6','$ketng7','$ket1','$ket2','$ket3','$ket4','$ket5','$ket6','$ket7','$total','$totalng','$totaljam','$nama','$nik','$sisa')";
    $query = mysqli_query($db, $sql);

    // apakah query simpan berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: index.php?status=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: index.php?status=gagal');
    }


} else {
    die("Akses dilarang...");
}

?>
