          <?php include("koneksi.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>List Mesin</title>
</head>

<body>
    <header>
        <h3>LIST MESIN PRODUKSI</h3>
    </header>

    <nav>
        <a href="ppic.php">[+] Tambah Baru</a>
    </nav>

    <br>

    <table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>No Mesin</th>
            <th>Nama Part</th>
            <th>Type Part</th>
            <th>No Order</th>
            <th>Jumlah Order</th>
            <th>Tindakan</th>
        </tr>
    </thead>
    <tbody>

        <?php
        $sql = "SELECT * FROM ppic";
        $query = mysqli_query($db, $sql);

        while($siswa = mysqli_fetch_array($query)){
            echo "<tr>";

            echo "<td>".$siswa['id']."</td>";
            echo "<td>".$siswa['nomc']."</td>";
            echo "<td>".$siswa['nama']."</td>";
            echo "<td>".$siswa['type']."</td>";
            echo "<td>".$siswa['noorder']."</td>";
            echo "<td>".$siswa['jumlah']."</td>";

            echo "<td>";
            echo "<a href='edit.php?id=".$siswa['id']."'>Edit</a> | ";
            echo "<a href='hapus.php?id=".$siswa['id']."'>Hapus</a>";
            echo "</td>";

            echo "</tr>";
        }
        ?>

    </tbody>
    </table>

    <p>Total: <?php echo mysqli_num_rows($query) ?></p>

    </body>
</html>
