<?php

include("koneksi.php");

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['save'])){

    // ambil data dari formulir
    $nomc = $_POST['nomc'];
    $nama = $_POST['nama'];
    $type = $_POST['type'];
    $noorder = $_POST['noorder'];
    $jumlah = $_POST['jumlah'];

    // buat query
    $sql = "INSERT INTO ppic (nomc, nama, type, noorder, jumlah) VALUE ('$nomc', '$nama', '$type', '$noorder', '$jumlah')";
    $query = mysqli_query($db, $sql);

    // apakah query simpan berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: ppic.php?status=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: ppic.php?status=gagal');
    }


} else {
    die("Akses dilarang...");
}

?>
