  <!DOCTYPE HTML>
<html>

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script type="text/javascript" src="common/js/form_init.js" id="form_init_script"
    data-name="">
    </script>
    <link rel="stylesheet" type="text/css" href="default.css"
    id="theme" />
    <title>
      PPIC
    </title>
  </head>

  <body><style>#docContainer .fb_cond_applied{ display:none; }</style><noscript><style>#docContainer .fb_cond_applied{ display:inline-block; }</style></noscript><form class="fb-toplabel fb-100-item-column selected-object" id="docContainer"
action="input.php" enctype="multipart/form-data" method="POST" novalidate="novalidate"
data-form="preview">
  <div class="fb-form-header" id="fb-form-header1">
    <a class="fb-link-logo" id="fb-link-logo1" style="max-width: 104px;" target="_blank"><img title="Alternative text" class="fb-logo" id="fb-logo1" style="width: 100%; display: none;" alt="Alternative text" src="common/images/image_default.png"/></a>
  </div>
  <div class="section" id="section1">
    <div class="column ui-sortable" id="column1">
      <div class="fb-item fb-100-item-column" id="item1">
        <div class="fb-header fb-item-alignment-center">
          <h2 style="display: inline;">
            Input Data Order PPIC
          </h2>
        </div>
      </div>
      <div class="fb-item" id="item7">
        <div class="fb-sectionbreak">
          <hr style="max-width: 960px;">
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item2">
        <div class="fb-grouplabel">
          <label id="item2_label_0" style="display: inline;">NOMOR MC</label>
        </div>
        <div class="fb-dropdown">
          <select name="nomc" id="4234" data-hint="">
            <option id="mc1" selected value="1">
              1
            </option>
            <option id="mc2" value="2">
              2
            </option>
            <option id="mc3" value="3">
              3
            </option>
          </select>
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item6">
        <div class="fb-grouplabel">
          <label id="item6_label_0" style="display: inline;">Nama Part</label>
        </div>
        <div class="fb-input-box">
          <input name="nama" id="434" required type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item8">
        <div class="fb-grouplabel">
          <label id="item8_label_0" style="display: inline;">Type</label>
        </div>
        <div class="fb-input-box">
          <input name="type" id="item8_text_1" type="text" maxlength="254" placeholder=""
          data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-20-item-column" id="item9">
        <div class="fb-grouplabel">
          <label id="item9_label_0">No Order</label>
        </div>
        <div class="fb-input-number">
          <input name="noorder" id="item9_number_1" type="number" min="0" max="999999999"
          step="1" data-hint="" autocomplete="off" />
        </div>
      </div>
      <div class="fb-item fb-25-item-column" id="item10">
        <div class="fb-grouplabel">
          <label id="item10_label_0" style="display: inline;">Jumlah Order</label>
        </div>
        <div class="fb-input-number">
          <input name="jumlah" id="item10_number_1" type="number" min="0" max="999999999"
          step="1" data-hint="" autocomplete="off" />
        </div>
      </div>
      </div>
    </div>
  </div>

  <div class="fb-captcha fb-item-alignment-center" id="fb-captcha_control"
  style="display: none; cursor: default;">
    <img src="editordata/images/recaptcharecaptchav2-light.png" />
  </div>
   <div class="fb-item-alignment-left fb-footer" id="fb-submit-button-div"
  style="min-height: 1px;">
    <input class="fb-button-special non-standard" id="fb-submit-button" style="border-width: 0px; font-family: times new roman; background-image: url('img/btn_submit.png');"
    type="submit" data-regular="url('file:img/btn_submit.png')"
    name="save" value="SAVE" />
  </div>
 </form>
<?php if(isset($_GET['status'])): ?>
    <p>
        <?php
            if($_GET['status'] == 'sukses'){
                echo "Input Data  berhasil!";
            } else {
                echo "Input data gagal!";
            }
        ?>
    </p>
<?php endif; ?>
</body>
</html>
