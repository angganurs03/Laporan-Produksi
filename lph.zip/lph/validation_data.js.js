 var data_validation = '{"fb-submit-button":{"hover":{"background-image":""}},"tgl":{"required":true,"messages":"wajib diisi"}}';
 var data_jsplugins = '[]';
 var data_cssplugins = '[]';