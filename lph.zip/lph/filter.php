
<?php
if(ISSET($_POST['cari'])){
 require 'config.php';
 $nomc = $_POST['nomc'];
 $query = mysqli_query($conn, "SELECT * FROM `ppic` WHERE nomc = '$nomc' ORDER BY `nomc` ASC") or die(mysqli_error());
 while($fetch = mysqli_fetch_array($query)){
  ?>
  <tr>
   <td><?php echo $fetch['nama']?></td>
   <td><?php echo $fetch['type']?></td>
   <td><?php echo $fetch['nomc']?></td>
  </tr>
  <?php
 }
}
?>

