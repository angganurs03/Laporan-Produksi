-- phpMyAdmin SQL Dump
-- version 4.1.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 16, 2019 at 04:01 AM
-- Server version: 5.1.62
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `lph`
--

CREATE TABLE IF NOT EXISTS `lph` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `type` varchar(15) NOT NULL,
  `noorder` varchar(15) NOT NULL,
  `jumlah1` varchar(15) NOT NULL,
  `nomesin` varchar(15) NOT NULL,
  `status` varchar(15) NOT NULL,
  `tanggal` varchar(15) NOT NULL,
  `jam1` varchar(15) NOT NULL,
  `jam2` varchar(15) NOT NULL,
  `jam3` varchar(15) NOT NULL,
  `jam4` varchar(15) NOT NULL,
  `jam5` varchar(15) NOT NULL,
  `jam6` varchar(15) NOT NULL,
  `jam7` varchar(15) NOT NULL,
  `ng1` varchar(15) NOT NULL,
  `ng2` varchar(15) NOT NULL,
  `ng3` varchar(15) NOT NULL,
  `ng4` varchar(15) NOT NULL,
  `ng5` varchar(15) NOT NULL,
  `ng6` varchar(15) NOT NULL,
  `ng7` varchar(15) NOT NULL,
  `ketng1` varchar(15) NOT NULL,
  `ketng2` varchar(15) NOT NULL,
  `ketng3` varchar(15) NOT NULL,
  `ketng4` varchar(15) NOT NULL,
  `ketng5` varchar(15) NOT NULL,
  `ketng6` varchar(15) NOT NULL,
  `ketng7` varchar(15) NOT NULL,
  `ket1` varchar(15) NOT NULL,
  `ket2` varchar(15) NOT NULL,
  `ket3` varchar(15) NOT NULL,
  `ket4` varchar(15) NOT NULL,
  `ket5` varchar(15) NOT NULL,
  `ket6` varchar(15) NOT NULL,
  `ket7` varchar(15) NOT NULL,
  `total` varchar(15) NOT NULL,
  `totalng` varchar(15) NOT NULL,
  `totaljam` varchar(15) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `nik` varchar(15) NOT NULL,
  `sisa` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `lph`
--

INSERT INTO `lph` (`id`, `name`, `type`, `noorder`, `jumlah1`, `nomesin`, `status`, `tanggal`, `jam1`, `jam2`, `jam3`, `jam4`, `jam5`, `jam6`, `jam7`, `ng1`, `ng2`, `ng3`, `ng4`, `ng5`, `ng6`, `ng7`, `ketng1`, `ketng2`, `ketng3`, `ketng4`, `ketng5`, `ketng6`, `ketng7`, `ket1`, `ket2`, `ket3`, `ket4`, `ket5`, `ket6`, `ket7`, `total`, `totalng`, `totaljam`, `nama`, `nik`, `sisa`) VALUES
(8, 'adidas', 'K11', '1910123', '7000', '2', 'Produksi', '2019-10-15', '50', '50', '50', '50', '50', '50', '50', '0', '0', '0', '0', '0', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '350', '0', '8', 'Dimas ', '1901657', '6650'),
(7, 'adidas', 'K11', '1910123', '7000', '2', 'Produksi', '2019-10-13', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ppic`
--

CREATE TABLE IF NOT EXISTS `ppic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomc` varchar(11) NOT NULL,
  `nama` varchar(11) NOT NULL,
  `type` varchar(11) NOT NULL,
  `noorder` varchar(11) NOT NULL,
  `jumlah` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `ppic`
--

INSERT INTO `ppic` (`id`, `nomc`, `nama`, `type`, `noorder`, `jumlah`) VALUES
(1, '77', 'adidas', 'k10', '1910567', '5000'),
(2, '2', 'adidas', 'K11', '1910123', '7000'),
(7, '3', 'Adidas3', 'A100', '190164646', '5000'),
(8, '3', 'Adidas3', 'A11', '196098', '5000');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
